import hashlib, json, pathlib, re, subprocess
repo=pathlib.Path("/workspace/scratch/4bed741d4966/repos/rea-probe")
out=pathlib.Path("/workspace/scratch/4bed741d4966/audit/rea-png-history")
out.mkdir(parents=True,exist_ok=True)
def git(*args):
    print("GIT_START", " ".join(args[:9]), flush=True)
    result=subprocess.check_output(["git",*args],cwd=repo,text=True,timeout=240)
    print("GIT_DONE", " ".join(args[:4]), len(result), flush=True)
    return result
assert git("rev-parse","--is-shallow-repository").strip()=="false"
refs=git("for-each-ref","--format=%(refname) %(objectname)","refs/audit-upstream","refs/audit-fork").splitlines()
paths=json.loads((out/"seed-paths.json").read_text())
print("Reusing completed historical filename sweep",len(paths),flush=True)
(out/"seed-paths.json").write_text(json.dumps(paths,indent=2))
# The filename sweep already includes all historical PNG/screenshot owners.
# Follow rename edges for production owners; no test/helper rename can hide production.
owner_seeds=[p for p in paths if p.startswith("src/") and not p.endswith(".test.ts")]
changes=git("log","--all","--full-history","-m","--format=","--name-status","-M","--",*owner_seeds).splitlines()
for line in changes:
    cols=line.split("\t")
    if cols and cols[0].startswith(("R","C")):
        for path in cols[1:]:
            if path not in paths:paths.append(path)
paths.sort()

variants={}
for line in git("log","--all","--full-history","-m","--format=","--raw","--no-abbrev","--no-renames","--",*paths).splitlines():
    if not line.startswith(":") or "\t" not in line:continue
    fields,path=line.split("\t",1)
    cols=fields.split()
    for sha in cols[2:4]:
        if sha!="0"*40: variants.setdefault(sha,set()).add(path)
owners=[]
for sha,names in sorted(variants.items()):
    if all(not p.startswith("src/") or p.endswith(".test.ts") for p in names):continue
    source=git("cat-file","blob",sha)
    if not re.search("unfilter|paeth|applyFilter",source,re.I):continue
    if all("/test" in p or p.endswith(".test.ts") or p.startswith("scripts/") for p in names):continue
    (out/(sha+".txt")).write_text(source)
    match=re.search(r"(?:const|function|async function)\s+unfilter\b",source)
    block=source[match.start():] if match else source
    stop=block.find("\nconst expandRgba")
    if stop>=0:block=block[:stop]
    owners.append({"blob":sha,"paths":sorted(names),"owner":block,"full_source_sha256":hashlib.sha256(source.encode()).hexdigest()})
summary={"ref_count":len(refs),"upstream_refs":sum(x.startswith("refs/audit-upstream/") for x in refs),"fork_refs":sum(x.startswith("refs/audit-fork/") for x in refs),"refs":refs,"commit_count":int(git("rev-list","--all","--count")),"paths":paths,"related_blob_count":len(variants),"owners":owners,"scope":"Complete non-shallow upstream heads/tags/PR heads plus user-fork heads/tags. All intermediate/reverted/merge-parent variants, filename seed and rename closure. Needs semantic review.","complete":True}
(out/"history.json").write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ("refs","owners","paths")}),flush=True)
for item in owners:print(json.dumps(item),flush=True)

